<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>CUSAT | Billing</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/flat/blue.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="plugins/morris/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
  <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <script>
function getState(val) {
	$.ajax({
	type: "POST",
	url: "get_state.php",
	data:'remtype='+val,
	success: function(data){
		$("#state-list").html(data);
	}
	});
}


function getRate(val) {
	$.ajax({
	type: "POST",
	url: "get_rate.php",
	data:'rate='+val,
	success: function(data){
        var data1=data;
		var txt =  document.getElementById('ratetext');
   txt.value = data1;
	}
	});	
}

function getTot()
{
	var rate=document.getElementById('ratetext');
	var qty1=document.getElementById('qty');
	var tot=document.getElementById('tot');
	tot.value=rate.value *qty1.value;
}
function selectCountry(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}
</script>
    
</head>
<body class="hold-transition sidebar-mini">
<?php
date_default_timezone_set("Asia/Calcutta");
$conn = new mysqli("localhost","root","","billing_db");
$sql = "SELECT DISTINCT rem_type from perticular_tb";
$result = $conn->query($sql);
?>
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="index.html" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link"></a>
      </li>
        <li class="nav-item d-none d-sm-inline-block ">
        <?php $today = date('d-m-Y'); echo $today; ?>
      </li>
        
    </ul>

    <!-- SEARCH FORM -->
    <form class="form-inline ml-3">
      <div class="input-group input-group-sm">
        <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
        <div class="input-group-append">
          <button class="btn btn-navbar" type="submit">
            <i class="fa fa-search"></i>
          </button>
        </div>
      </div>
    </form>

    <!-- Right navbar links -->
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <?php include('side.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <br>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
           
<div class="card">
            <div class="card-header">
              <h3 class="card-title">All Transactions</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
            
              <form action="#" method="POST">
              <div class="row">
              <div class="col-sm-6">
              <div class="form-group">
                  <label>Select the range:</label>

                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text">
                        <i class="fa fa-calendar"></i>
                      </span>
                    </div>
                    <input class="form-control float-right active" id="reservation" type="text" name="dates" required>
                  </div>
                  <!-- /.input group -->
                </div>
                
                
             
              </div>
             <div class="col-sm-3">
              <div class="form-group">
                    <label>Select</label>
                    <select class="form-control" name="modet">
                      <option value="Cash">Cash</option>
                      <option value="DD">Demant Draft</option>
                      <option value="CHEQUE">Cheque</option>
                      <option value="DDC">DD/Cheque</option>
                    </select>
                  </div>
                </div>
             </div>
             <div class="col-sm-3">


             <button type="submit" class="btn btn-primary " name="submit">Submit</button>
           
            </div>
              </form>
           
           
              <?php
            if(isset($_POST['submit']))
            {
            $drange=$_POST['dates'];
            list($d1,$d2)=explode('-',$drange);
            
            
            list($m1,$dy1,$y1)=explode('/',$d1);
            $m1=trim($m1);
            $dy1=trim($dy1);
            $y1=trim($y1);
             $dt1=$y1.'-'.$m1.'-'.$dy1;

            list($m2,$dy2,$y2)=explode('/',$d2);
            $m2=trim($m2);
            $dy2=trim($dy2);
            $y2=trim($y2);
           
            $dt2=$y2.'-'.$m2.'-'.$dy2;
            $dt3=trim($dt1);
            $dt4=trim($dt2);
            $mde=$_POST['modet'];
            $co = new mysqli("localhost","root","","billing_db");

            if(strcmp($mde,"DD")==0)
            {
                  $sq = "SELECT * from dd_tb WHERE date_p BETWEEN '".$dt3."' AND '".$dt4."' AND `mode`='DD'";
                  $rs1 = $co->query($sq);
                 

            }
            if(strcmp($mde,"CHEQUE")==0)
            {
                  $sq = "SELECT * from dd_tb WHERE date_p BETWEEN '".$dt3."' AND '".$dt4."' AND `mode`='CHEQUE'";
                  $rs1 = $co->query($sq);
                 

            }
            if(strcmp($mde,"DDC")==0)
            {
                  $sq = "SELECT * from dd_tb WHERE date_p BETWEEN '".$dt3."' AND '".$dt4."'";
                  $rs1 = $co->query($sq);
                 

            }

            if(strcmp($mde,"Cash")==0)
            {
                  $sq = "SELECT * from cash_tb WHERE date_p BETWEEN '".$dt3."' AND '".$dt4."'";
                  $rs1 = $co->query($sq);
                 

            }
         
          ?>
          <br>
            <div class="row">
              <div class="col-sm-12">
                <table aria-describedby="example1_info" role="grid" class="table table-bordered table-striped dataTable" id="testTable" summary="Code page support in different versions of MS Windows." rules="groups" frame="hsides">
                
                <thead>
                <?php if((strcmp($mde,"DD")==0)||(strcmp($mde,"CHEQUE")==0)||(strcmp($mde,"DDC")==0)) {?>
                <tr role="row">
                  <th>Receipt No</th>
                  <th>Mode</th>
                  <th>DD/C No</th>
                  <th>DD/C Date</th>
                  <th>Bank</th>
                  <th>Branch/Code</th>
                  <th>Date/Time</th>
                  <th>Name</th>
                  <th>Address</th>
                  <th>Type</th>
                  <th>Particular</th>
                  <th>Qty</th>
                  <th>Total</th>
                  </tr>
                </thead>
                <tbody>
                <?php while($row2 = $rs1->fetch_array()) { ?>
                <tr class="odd" role="row">
                  <td><?php echo $row2['receipt_no'];?></td>
                  <td><?php echo $row2['mode'];?></td>
                  <td><?php echo $row2['dd_no'];?></td>
                  <td><?php echo $row2['dd_date'];?></td>
                  <td><?php echo $row2['bankname'];?></td>
                  <td><?php echo $row2['branch']."/".$row2['branchcode'];?></td>
                  <td><?php echo $row2['date_p']." ".$row2['time_p'];?></td>
                  <td><?php echo $row2['rem_name'];?></td>
                  <td><?php echo $row2['rem_add'];?></td>
                  <td><?php echo $row2['rem_type'];?></td>
                  <td><?php echo $row2['particular'];?></td>
                  <td><?php echo $row2['qty'];?></td>
                  <td><?php echo $row2['total'];?></td>
                </tr>
                <?php 
                  }
                 }
                if(strcmp($mde,"Cash")==0) {?>
                    <tr role="row">
                  <th>Receipt No</th>
                  
                  <th>Date/Time</th>
                  <th>Name</th>
                  <th>Address</th>
                  <th>Type</th>
                  <th>Particular</th>
                  <th>Rate</th>
                  <th>Qty</th>
                  <th>Total</th>
                  </tr>
                </thead>
                <tbody>
                <?php while($row2 = $rs1->fetch_array()) { ?>
                <tr class="odd" role="row">
                  <td><?php echo $row2['receipt_no'];?></td>
                  <td><?php echo $row2['date_p']." ".$row2['time_p'];?></td>
                  <td><?php echo $row2['rem_name'];?></td>
                  <td><?php echo $row2['rem_add'];?></td>
                  <td><?php echo $row2['rem_type'];?></td>
                  <td><?php echo $row2['particular'];?></td>
                  <td><?php echo $row2['rate'];?></td>
                  <td><?php echo $row2['qty'];?></td>
                  <td><?php echo $row2['total'];?></td>
                </tr>
              <?php    
               } 
               }?>
              <button class="btn btn-success" id="btnExport" onclick="javascript:xport.toXLS('testTable', 'outputdata');"> Export to CSV</button> <?php
             }?>

              </tbody>
               
              </table>
            <!-- /.card-body -->
          </div>
           
          </div>
          </section>
  


  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script type="text/javascript">
var xport = {
  _fallbacktoCSV: true,  
  toXLS: function(tableId, filename) {   
    this._filename = (typeof filename == 'undefined') ? tableId : filename;
    
    //var ieVersion = this._getMsieVersion();
    //Fallback to CSV for IE & Edge
    if ((this._getMsieVersion() || this._isFirefox()) && this._fallbacktoCSV) {
      return this.toCSV(tableId);
    } else if (this._getMsieVersion() || this._isFirefox()) {
      alert("Not supported browser");
    }

    //Other Browser can download xls
    var htmltable = document.getElementById(tableId);
    var html = htmltable.outerHTML;

    this._downloadAnchor("data:application/vnd.ms-excel" + encodeURIComponent(html), 'xls'); 
  },
  toCSV: function(tableId, filename) {
    this._filename = (typeof filename === 'undefined') ? tableId : filename;
    // Generate our CSV string from out HTML Table
    var csv = this._tableToCSV(document.getElementById(tableId));
    // Create a CSV Blob
    var blob = new Blob([csv], { type: "text/csv" });

    // Determine which approach to take for the download
    if (navigator.msSaveOrOpenBlob) {
      // Works for Internet Explorer and Microsoft Edge
      navigator.msSaveOrOpenBlob(blob, this._filename + ".csv");
    } else {      
      this._downloadAnchor(URL.createObjectURL(blob), 'csv');      
    }
  },
  _getMsieVersion: function() {
    var ua = window.navigator.userAgent;

    var msie = ua.indexOf("MSIE ");
    if (msie > 0) {
      // IE 10 or older => return version number
      return parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)), 10);
    }

    var trident = ua.indexOf("Trident/");
    if (trident > 0) {
      // IE 11 => return version number
      var rv = ua.indexOf("rv:");
      return parseInt(ua.substring(rv + 3, ua.indexOf(".", rv)), 10);
    }

    var edge = ua.indexOf("Edge/");
    if (edge > 0) {
      // Edge (IE 12+) => return version number
      return parseInt(ua.substring(edge + 5, ua.indexOf(".", edge)), 10);
    }

    // other browser
    return false;
  },
  _isFirefox: function(){
    if (navigator.userAgent.indexOf("Firefox") > 0) {
      return 1;
    }
    
    return 0;
  },
  _downloadAnchor: function(content, ext) {
      var anchor = document.createElement("a");
      anchor.style = "display:none !important";
      anchor.id = "downloadanchor";
      document.body.appendChild(anchor);

      // If the [download] attribute is supported, try to use it
      
      if ("download" in anchor) {
        anchor.download = this._filename + "." + ext;
      }
      anchor.href = content;
      anchor.click();
      anchor.remove();
  },
  _tableToCSV: function(table) {
    // We'll be co-opting `slice` to create arrays
    var slice = Array.prototype.slice;

    return slice
      .call(table.rows)
      .map(function(row) {
        return slice
          .call(row.cells)
          .map(function(cell) {
            return '"t"'.replace("t", cell.textContent);
          })
          .join(",");
      })
      .join("\r\n");
  }
};

</script>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Morris.js charts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="plugins/morris/morris.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/knob/jquery.knob.js"></script>
<!-- daterangepicker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Select2 -->
<script src="plugins/select2/select2.full.min.js"></script>
<!-- InputMask -->
<script src="plugins/input-mask/jquery.inputmask.js"></script>
<script src="plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="../../plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap color picker -->
<script src="plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- Page script -->
<script>

  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
      timePicker         : true,
      timePickerIncrement: 30,
      format             : 'MM/DD/YYYY h:mm A'
    })
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })
</script>
</body>
</html>