<?php
$conn = new mysqli("localhost","root","","billing_db");
if(!empty($_POST["remtype"])) {
    $sql = "SELECT DISTINCT `perticulars` FROM perticular_tb WHERE rem_type = '" . $_POST["remtype"] . "' ORDER BY perticulars";
$result = $conn->query($sql);
?>
<option>Select Perticular</option>
<?php
	while($row = $result->fetch_assoc())  {
?>
	<option value="<?php echo $row["perticulars"]; ?>" name="perti"><?php echo $row["perticulars"]; ?></option>
<?php
	}
}
?>