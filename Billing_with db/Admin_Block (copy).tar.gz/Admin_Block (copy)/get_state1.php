<?php
$conn2= new mysqli("localhost","root","","billing_db");
if(!empty($_POST["remtype1"])) {
    $sql2 = "SELECT DISTINCT `perticulars` FROM perticular_tb WHERE rem_type = '" . $_POST["remtype1"] . "' ORDER BY perticulars";
$result2 = $conn2->query($sql2);
?>
<option>Select Perticular</option>
<?php
	while($row2 = $result2->fetch_assoc())  {
?>
	<option value="<?php echo $row2["perticulars"]; ?>" name="perti"><?php echo $row2["perticulars"]; ?></option>
<?php
	}
}
?>