<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>CUSAT | Billing</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/flat/blue.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="plugins/morris/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
  <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <script>
function getState(val) {
	$.ajax({
	type: "POST",
	url: "get_state.php",
	data:'remtype='+val,
	success: function(data){
		$("#state-list").html(data);
	}
	});
}

function getRate(val) {
	$.ajax({
	type: "POST",
	url: "get_rate.php",
	data:'rate='+val,
	success: function(data){
        var data1=data;
		var txt =  document.getElementById('ratetext');
   txt.value = data1;
	}
	});	
}

function getTot()
{
	var rate=document.getElementById('ratetext');
	var qty1=document.getElementById('qty');
	var tot=document.getElementById('tot');
	tot.value=rate.value *qty1.value;
}
function selectCountry(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}
</script>
    
</head>
<body class="hold-transition sidebar-mini">
<?php
$conn = new mysqli("localhost","root","","billing_db");
$sql = "SELECT DISTINCT rem_type from perticular_tb";
$result = $conn->query($sql);
?>
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="index.html" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link"></a>
      </li>
        <li class="nav-item d-none d-sm-inline-block ">
        <?php $today = date('d-m-Y'); echo $today; ?>
      </li>
        
    </ul>

    <!-- SEARCH FORM -->
    <form class="form-inline ml-3">
      <div class="input-group input-group-sm">
        <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
        <div class="input-group-append">
          <button class="btn btn-navbar" type="submit">
            <i class="fa fa-search"></i>
          </button>
        </div>
      </div>
    </form>

    <!-- Right navbar links -->
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="index.html" class="brand-link">
      
      <span class="brand-text font-weight-light">CUSAT</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="info">
          <a href="#" class="d-block">Admin Name</a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
              <li class="nav-item has-treeview ">
            <a href="#" class="nav-link active">
              <i class="nav-icon fa fa-dashboard"></i>
              <p>
                File
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="./index.html" class="nav-link active">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>option 1</p>
                </a>
              </li>
            </ul>
          </li>
            
                        
          <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fa fa-dashboard"></i>
              <p>
                Edit
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="./index.html" class="nav-link active">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>option 1</p>
                </a>
              </li>
            </ul>
          </li>
            
               <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fa fa-dashboard"></i>
              <p>
                View
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="./index.html" class="nav-link active">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>Budget Head</p>
                </a>
              </li>
                <li class="nav-item">
                <a href="./index.html" class="nav-link active">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>Cancelled Receipt</p>
                </a>
              </li>
                <li class="nav-item">
                <a href="./index.html" class="nav-link active">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>Date Wise Reports</p>
                </a>
              </li>
                <li class="nav-item">
                <a href="./index.html" class="nav-link active">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>Draft Payments</p>
                </a>
              </li>
                <li class="nav-item">
                <a href="./index.html" class="nav-link active">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>Main Details</p>
                </a>
              </li>
            </ul>
          </li>
            
             <li class="nav-item has-treeview">
            <a href="#" class="nav-link">
              <i class="nav-icon fa fa-dashboard"></i>
              <p>
                Properties
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="./index.html" class="nav-link active">
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>option 1</p>
                </a>
              </li>
            </ul>
          </li>
              <li class="nav-item">
            <a href="https://adminlte.io/docs" class="nav-link">
              <i class="nav-icon fa fa-file"></i>
              <p>About</p>
            </a>
          </li>
       
            </ul>
          
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <br>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
           

        <div class="row">
          <div class="col-9">
            <!-- Custom Tabs -->
            <div class="card card-info">
              <div class="card-header d-flex p-0">
                <h3 class="card-title p-3">Mode of Transaction</h3>
                <ul class="nav nav-pills ml-auto p-2">
                  <li class="nav-item"><a class="nav-link active" href="#tab_1" data-toggle="tab">Cash</a></li>
                  <li class="nav-item"><a class="nav-link" href="#tab_2" data-toggle="tab">Demand Draft</a></li>
                   <li class="nav-item"><a class="nav-link" href="#tab_3" data-toggle="tab">Cheque</a></li>
                  <li class="nav-item"><a class="nav-link" href="#tab_4" data-toggle="tab">Online Trans</a></li>
                  
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="tab_1">
                    <form action="bill2.php" method="POST">
                    <div class="row"> 
                    <div class="form-group col-lg-4">
                    <label>Party Category</label>
                    <select class="form-control">
                      <option value="STU">STU</option>
                      <option value="EMP">EMP</option>
                      <option value="TEC">TEC</option>
                    </select>
                  </div>
                 <div class="form-group col-lg-8 "> 
                    <label>Name of Remitter</label>
                    <input type="text" class="form-control" name="remitter">
                </div> 
                
                </div>
                      
               
                <div class="form-group col-lg-10 ">
                    <label>Address of Remitter</label>
                    <textarea class="form-control" rows="3" name="address"></textarea>
                  </div>
                <div class="row"> 
                    <div class="form-group col-lg-4">
                    <label>Type of Remitter</label>
                    
                       <select id="country-list" class="form-control" onChange="getState(this.value);" name="remi">
                           <option value="">Select Type</option>
                      <?php while($row = $result->fetch_assoc()) 
	                       {?>
                                <option value='<?php echo $row['rem_type']; ?>' name="remi"> <?php echo $row['rem_type']; ?> </option>
	                       <?php } ?>
                    </select>
                    
                    </div>
                       <div class="form-group col-lg-4">
                    <label>Perticulars</label>
                           <select id="state-list" class="form-control" onChange="getRate(this.value);" name="perti">
                               <option  name="perti">Select Perticular</option>
                           </select>
                    </div>
                    <div class="form-group col-lg-2 "> 
                    <label>Rate</label>
                    <input type="text" class="form-control" id="ratetext" name="ratename" onkeyup="getTot()" >
                </div> 
                <div class="form-group col-lg-2 "> 
                    <label>Qty</label>
                    <input type="text" class="form-control" id="qty" name="qty" onkeyup="getTot()" >
                </div> 
                </div>
                  
                 
                      
                <div class="row"> 
                <div class="form-group col-lg-4">
                    <select class="form-control">
                      <option value="Plan">Plan</option>
                      <option value="Nonplan">Non-Plan</option>
                    </select>
                  </div> 
                 <div class="form-group col-lg-1 ">
                    <input type="text" class="form-control" name="budget1">
                </div>
                <div class="form-group col-lg-1 ">
                    <input type="text" class="form-control" name="budget2">
                </div>
                <div class="form-group col-lg-1 ">
                    <input type="text" class="form-control" name="budget3">
                </div>
                <div class="form-group col-lg-1 ">
                    <input type="text" class="form-control" name="budget4">
                </div>
                </div>
                <div class="form-group col-lg-5">
                    <label>Total</label>
                    <input type="text" class="form-control" id="tot" name="tot" >
                </div>
	  
                <button type="submit" class="btn btn-primary float-right">Submit</button>
             </form>
                  </div>
                   
                  <!-- /.tab-pane -->
             <div class="tab-pane" id="tab_2">
             
                 <div class="row"> 
                     <div class="form-group col-lg-6 ">
                     <label>DD No</label>
                    <input type="text" class="form-control">
                </div>
                
                 <div class="form-group col-lg-4 ">
                     <div class="float-right">
                     <label>DD Date</label>
                    <input type="date" class="form-control">
                  </div>
                    </div>
                </div>
                
                <div class="form-group col-lg-10 "> 
                    <input type="text" class="form-control" placeholder="Name of Bank">
                </div>      
                
                <div class="row"> 
                     <div class="form-group col-lg-5 ">
                    <input type="text" class="form-control" placeholder="Branch">
                </div>
                
                 <div class="form-group col-lg-5 ">
                     <div class="float-right">
                    <input type="text" class="form-control" placeholder="Branch Code">
                  </div>
                    </div>
                </div>
                 
                      
                     <div class="row"> 
                    <div class="form-group col-lg-4">
                    <label>Party Category</label>
                    <select class="form-control" >
                      
                    </select>
                  </div>
                
                 <div class="form-group col-lg-6 ">
                     <div class="float-right">
                    <label>Party Code</label>
                    <input type="text" class="form-control" >
                  </div>
                </div>
                </div>
                      
                <div class="form-group col-lg-10 "> 
                    
                    <input type="text" class="form-control" placeholder="Name of Remitter">
                </div> 
                <div class="form-group col-lg-10 ">
                    <textarea class="form-control" rows="3" placeholder="Address of Remitter"></textarea>
                  </div>
                <div class="row"> 
                    <div class="form-group col-lg-5">
                    <label>Type of Remitter</label>
                    <select class="form-control">
                      <option>Internal Revenue</option>
                      <option>Scheme Funds </option>
                      <option>Refunds</option>
                      <option>Dept Heads</option>
                      <option>Plan</option>
                      <option>PF</option>
                      <option>SOE</option>
                    </select>
                    </div>
                        <div class="form-group col-lg-5">
                            <div class="float-right">
                            <label>Perticulars</label><br>
                        <button type="submit" class="btn btn-default">Perticulars</button>
                            </div>
                            <div>
                        
                  </div>  
                    </div>
                </div>
                      
                      
                 <div class="form-group col-lg-5 ">
                    <input type="text" class="form-control" placeholder="Total">
                </div>
                <button type="submit" class="btn btn-primary float-right">Submit</button>
                  </div>
                  <!-- /.tab-pane -->
                 
        
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
                
                
              </div>
                
                
            </div>
            <!-- ./card -->
         
          <!-- /.col -->
          <div class="col-lg-3">
            <div class="info-box bg-primary">
              <span class="info-box-icon"><i class="fa fa-calendar"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Today's Collection</span>

                <div class="progress">
                  <div class="progress-bar" style="width: 100%"></div>
                </div>
                <span class="progress-description">
                  Total:
                </span>
                  <span class="progress-description">
                  Cash:
                </span> 
                <span class="progress-description">
                  DD/Cheque:
                </span>   
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
        </div>
           
          </div>
          </section>
  


  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Morris.js charts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="plugins/morris/morris.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/knob/jquery.knob.js"></script>
<!-- daterangepicker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
</body>
</html>
