<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>CUSAT | Billing</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/flat/blue.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="plugins/morris/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker-bs3.css">
  <script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <script>
function getState(val) {
  $.ajax({
  type: "POST",
  url: "get_state.php",
  data:'remtype='+val,
  success: function(data){
    $("#state-list").html(data);
  }
  });
}

function getState1(val) {
  $.ajax({
  type: "POST",
  url: "get_state1.php",
  data:'remtype1='+val,
  success: function(data){
    $("#state-list1").html(data);
  }
  });
}

function getRate(val) {
  $.ajax({
  type: "POST",
  url: "get_rate.php",
  data:'rate='+val,
  success: function(data){
        var data1=data;
    var txt =  document.getElementById('ratetext');
   txt.value = data1;
  }
  }); 
}

function getTot()
{
  var rate=document.getElementById('ratetext');
  var qty1=document.getElementById('qty');
  var tot=document.getElementById('tot');
  tot.value=rate.value *qty1.value;
}
function selectCountry(val) {
$("#search-box").val(val);
$("#suggesstion-box").hide();
}
</script>
    
</head>
<body class="hold-transition sidebar-mini">
<?php
date_default_timezone_set("Asia/Calcutta");
$conn = new mysqli("localhost","root","","billing_db");
$sql = "SELECT DISTINCT rem_type from perticular_tb";
$result = $conn->query($sql);
?>
<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="index.html" class="nav-link">Home</a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="#" class="nav-link"></a>
      </li>
        <li class="nav-item d-none d-sm-inline-block ">
        <?php $today = date('d-m-Y'); echo $today; ?>
      </li>
        
    </ul>

    <!-- SEARCH FORM -->
    <form class="form-inline ml-3">
      <div class="input-group input-group-sm">
        <input class="form-control-navbarl form-control-navbar" type="search" placeholder="Search" aria-label="Search">
        <div class="input-group-append">
          <button class="btn btn-navbar" type="submit">
            <i class="fa fa-search"></i>
          </button>
        </div>
      </div>
    </form>

    <!-- Right navbar links -->
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->

    <!-- Sidebar -->
    <?php include('side.php'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <br>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
           

        <div class="row">
          <div class="col-9">
            <!-- Custom Tabs -->
            <div class="card card-info">
              <div class="card-header d-flex p-0">
                <h3 class="card-title p-3">Receipt No#:<?php include('receipt_no.php'); ?></h3>
                <ul class="nav nav-pills ml-auto p-2">
                  <li class="nav-item"><a class="nav-link active" data-toggle="tab">Cheque</a></li>      
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="tab_1">
                    <form action="cheque_print.php" method="POST">
             
                 <div class="row"> 
                     <div class="form-group col-lg-6 ">
                     <label>Cheque No</label>
                    <input type="text" class="form-control" name="ddno">
                </div>
                <div class="form-group col-lg-4">
                  <label>Cheque Date</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fa fa-calendar"></i></span>
                    </div>
                    <input type="text" name="dddate" class="form-control" data-inputmask="'alias': 'mm/dd/yyyy'" data-mask >
                  </div>
                  <!-- /.input group -->
                </div>
              </div>
                 
                

                <div class="form-group col-lg-10 "> 
                    <input type="text" class="form-control" name="bank" placeholder="Name of Bank">
                </div>      
                
                <div class="row"> 
                     <div class="form-group col-lg-5 ">
                    <input type="text" class="form-control" name="branch" placeholder="Branch">
                </div>
                
                 <div class="form-group col-lg-5 ">
                     <div class="float-right">
                    <input type="text" class="form-control" name="bcode" placeholder="Branch Code">
                  </div>
                    </div>
                </div>
                 
                      
                    <div class="row"> 
                    <div class="form-group col-lg-4">
                    <label>Party Category</label>
                    <select class="form-control" name="party">
                      <option value="STU">STU</option>
                      <option value="EMP">EMP</option>
                      <option value="TEC">TEC</option>
                    </select>
                  </div>
                 <div class="form-group col-lg-6 "> 
                    <label>Name of Remitter</label>
                    <input type="text" class="form-control" name="remitter">
                </div> 
                
                </div>
        
                <div class="form-group col-lg-10 ">
                    <label>Address of Remitter</label>
                    <textarea class="form-control" rows="3" name="address"></textarea>
                  </div>
                <div class="row"> 
                    <div class="form-group col-lg-4">
                    <label>Type of Remitter</label>
                    
                       <select id="pertic" class="form-control" onChange="getState1(this.value);" name="remit">
                           <option value="">Select Type</option>
                      <?php while($row = $result->fetch_assoc()) 
                         {?>
                                <option value='<?php echo $row['rem_type']; ?>' name="remitt"> <?php echo $row['rem_type']; ?> </option>
                         <?php } ?>
                    </select>
                    
                    </div>
                       <div class="form-group col-lg-4">
                    <label>Perticulars</label>
                           <select id="state-list1" class="form-control" onChange="getRate(this.value);" name="perti">
                               <option  name="perti">Select Perticular</option>
                           </select>
                    </div>
                    <div class="form-group col-lg-2 "> 
                    <label>Rate</label>
                    <input type="text" class="form-control" id="ratetext" name="ratename" onkeyup="getTot()" >
                </div> 
                <div class="form-group col-lg-2 "> 
                    <label>Qty</label>
                    <input type="text" class="form-control" id="qty" name="qty" onkeyup="getTot()" >
                </div> 
                </div>
                  
                 
                      
                <div class="row"> 
                <div class="form-group col-lg-4">
                    <select class="form-control" name="budget">
                      <option value="Plan">Plan</option>
                      <option value="Nonplan">Non-Plan</option>
                    </select>
                  </div> 
                 <div class="form-group col-lg-1 ">
                    <input type="text" class="form-control" name="budget1">
                </div>
                <div class="form-group col-lg-1 ">
                    <input type="text" class="form-control" name="budget2">
                </div>
                <div class="form-group col-lg-1 ">
                    <input type="text" class="form-control" name="budget3">
                </div>
                <div class="form-group col-lg-1 ">
                    <input type="text" class="form-control" name="budget4">
                </div>
                </div>
                <div class="form-group col-lg-5">
                    <label>Total</label>
                    <input type="text" class="form-control" id="tot" name="tot" >
                </div>
                <button type="submit" class="btn btn-primary float-right" name="submit" value="CHEQUE">Print</button>
              </form>
                  </div>
                  <!-- /.tab-pane -->
                 
        
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
                
                
              </div>
                
                
            </div>
            <!-- ./card -->
         
          <!-- /.col -->
         <div class="col-lg-3">
            <div class="info-box bg-primary">
              <span class="info-box-icon"><i class="fa fa-calendar"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Today's Collection</span>
                <?php include('daily_report.php'); ?>
                <div class="progress">
                  <div class="progress-bar" style="width: 100%"></div>
                </div>
                <span class="progress-description">
                  Total:&#8377;<?php echo" ".$gtot;?>
                </span>
                  <span class="progress-description">
                  Cash:&#8377;<?php echo " ".$cash_t;?>
                </span> 
                <span class="progress-description">
                  DD:&#8377;<?php echo " ".$dd_t;?>
                </span> 
                <span class="progress-description">
                Cheque:&#8377;<?php echo " ".$cheque_t;?>
                </span>   
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
        </div>
           
          </div>
          </section>
  


  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button)
</script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Morris.js charts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="plugins/morris/morris.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/knob/jquery.knob.js"></script>
<!-- daterangepicker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Select2 -->
<script src="plugins/select2/select2.full.min.js"></script>
<!-- InputMask -->
<script src="plugins/input-mask/jquery.inputmask.js"></script>
<script src="plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="../../plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap color picker -->
<script src="plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- Page script -->
<script>
  $(function () {
    //Initialize Select2 Elements
    $('.select2').select2()

    //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date range picker
    $('#reservation').daterangepicker()
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({
      timePicker         : true,
      timePickerIncrement: 30,
      format             : 'MM/DD/YYYY h:mm A'
    })
    //Date range as a button
    $('#daterange-btn').daterangepicker(
      {
        ranges   : {
          'Today'       : [moment(), moment()],
          'Yesterday'   : [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days' : [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month'  : [moment().startOf('month'), moment().endOf('month')],
          'Last Month'  : [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        },
        startDate: moment().subtract(29, 'days'),
        endDate  : moment()
      },
      function (start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
      }
    )

    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass   : 'iradio_minimal-red'
    })
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })

    //Colorpicker
    $('.my-colorpicker1').colorpicker()
    //color picker with addon
    $('.my-colorpicker2').colorpicker()

    //Timepicker
    $('.timepicker').timepicker({
      showInputs: false
    })
  })
</script>
</body>
</html>